function run(data) {
  return data;
}

function init() {
  // do nothing
}

exports.run = run;
exports.init = init;
