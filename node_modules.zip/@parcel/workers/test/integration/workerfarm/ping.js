function run() {
  return 'pong';
}

function init() {
  // do nothing
}

exports.run = run;
exports.init = init;
