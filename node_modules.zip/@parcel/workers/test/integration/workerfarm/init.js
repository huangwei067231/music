let options = {};

function run() {
  return options;
}

function init(opt) {
  options = opt;
}

exports.run = run;
exports.init = init;
