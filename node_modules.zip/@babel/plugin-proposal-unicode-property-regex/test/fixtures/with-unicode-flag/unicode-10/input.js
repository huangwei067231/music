var regex = /\p{Regional_Indicator}/u;
