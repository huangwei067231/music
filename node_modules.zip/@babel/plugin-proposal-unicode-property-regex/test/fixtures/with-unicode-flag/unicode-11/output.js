var regex = /[\u{11EE0}-\u{11EF8}]/u;
