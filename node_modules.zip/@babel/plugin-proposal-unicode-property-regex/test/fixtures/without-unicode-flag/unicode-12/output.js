var regex = /(?:\uD838[\uDEC0-\uDEF9\uDEFF])/;
